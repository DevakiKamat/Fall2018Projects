
<?php
if(session_id() == '' || !isset($_SESSION)){
session_start();
if(!isset($_SESSION["cart"]))
{
			$_SESSION["cart"] = array();
			$_SESSION["basketPrice"] = 0 ;
}
}	
?>

<?php
$proCategXmlResponse = file_get_contents('http://sandbox.api.ebaycommercenetwork.com/publisher/3.0/rest/CategoryTree?apiKey=78b0db8a-0ee1-4939-a2f9-d3cd95ec0fcc&visitorUserAgent&visitorIPAddress&trackingId=7000610&categoryId=72&showAllDescendants=true');
$ProCategxml = new SimpleXMLElement($proCategXmlResponse);
 ?>
 <?php
if(isset($_GET["category"]) && isset($_GET["keyword"])){
$selectCateg = $_GET["category"];
$searchKeyword = $_GET["keyword"];
$keyXmlResponse = file_get_contents('http://sandbox.api.shopping.com/publisher/3.0/rest/GeneralSearch?apiKey=78b0db8a-0ee1-4939-a2f9-d3cd95ec0fcc&visitorUserAgent&visitorIPAddress&trackingId=7000610&numItems=20&categoryId='.$selectCateg.'&keyword='.$searchKeyword);
$keySearchXml = new SimpleXMLElement($keyXmlResponse);
$_SESSION["searchResults"] = $keyXmlResponse;
}
?>
 <?php
 if(isset($_GET["select"])){
 $keySearchXml = new SimpleXMLElement($_SESSION["searchResults"]);
 foreach ($keySearchXml->categories->category->items->offer as $prodSelect) {
			if((string) $prodSelect['id'] == $_GET["select"]) {
				$_SESSION["cart"][$_GET["select"]]["id"]=(string)$prodSelect['id'];
				//print_r($_SESSION["cart"][$_GET["select"]]['id']);
				$_SESSION["cart"][$_GET["select"]]["Price"] =(double)$prodSelect->basePrice;
				$_SESSION["cart"][$_GET["select"]]["name"] = (string)$prodSelect->name;
				$_SESSION["basketPrice"] = (double)$_SESSION["basketPrice"] + (double)$prodSelect->basePrice;
				//print_r($_SESSION["basketPrice"]);
			}

		}
 		
	}

?>
<?php
	if(isset($_GET["delete"])){
		if($_SESSION["cart"][$_GET["delete"]] >= 1){
			$_SESSION["basketPrice"] = $_SESSION["basketPrice"] - (double)($_SESSION["cart"][$_GET["delete"]]["Price"]);
		}
		unset($_SESSION["cart"][$_GET["delete"]]);
	}
?>
<?php
	if(isset($_GET["clear"])){
		$_SESSION["cart"] = array();
		$_SESSION["basketPrice"] = 0 ;	
	}
?>

<html>
<head>
<style>
table, th, td {
border: 1px solid black;
}
#basket{
	background-color: lightblue;
}
#search
{
	background-color: lightblue;
}
p1
{
	background-color: lightgrey;
}
</style>

<body>
<?php if(empty($_SESSION["cart"])){?>
<b><img src="https://png.icons8.com/android/50/000000/buy.png"></b><br/>
<table border=1>
</table>
<br/>
Total: $0<br/>
<?php }?>
<?php if(!empty($_SESSION["cart"])){ ?>
	<p><img src="https://png.icons8.com/android/50/000000/buy.png"></p>
		<!-- <table border="2">
			<tbody>
				<tr>
					<th>Device</th> 
					<th>Price</th>
					<th></th>
				</tr> -->
				<p1>
				<?php foreach($_SESSION["cart"] as $cartItems) { ?>
				<!-- <tr> -->
					<?php print $cartItems['name'] ?></br>
					$ <?php print $cartItems['Price'] ?></br>
					<a href='buy.php?delete=<?php print $cartItems['id']?>'>Delete</a></br></br>
				<!-- </tr> -->
		     <?php }?>
		     <p1>
			<!-- </tbody> -->
			
		<!-- </table> -->
	<p><b>Total: </b>
	$ <?php if(isset($_SESSION)){ print $_SESSION["basketPrice"]; }?></p>
        <form action="buy.php" method="GET">
		<input type="hidden" name="clear" value="1">
		<input type="submit" value="Empty Basket" id="basket">
		</form>
		<?php }?>
		<form action="buy.php" method="GET">
 <fieldset>
  <legend>Find Products:</legend>
  <label>Category: 
				<select name="category">
					<option value="<?php  print $ProCategxml->category['id']?>">
						<?php print $ProCategxml->category->name ?>
					</option>
						<?php foreach($ProCategxml->category->categories->category as $ProCategList){?>
						<optgroup label="<?php print $ProCategList->name?>" value="<?php print $ProCategList['id'] ?>">
							<option value="<?php print $ProCategList['id']?>"><?php print $ProCategList->name ?></option>
							<?php 
								foreach($ProCategList->categories->category as $categ){ ?>
										<option value="<?php print $categ['id']?>">
										<?php print $categ->name ?></option>
										<?php } ?>
						</optgroup>
						<?php } ?>
				</select>

  </label>
  <label>Search Keywords:<input type="text" name="keyword" required>
  <label><input type="submit" value="Search" id="search"></label>
 </fieldset>
</form>
  <p>
		<?php if(isset($keySearchXml)): ?>
		<table border=2>
			<tr>
				<th>Device</th> 
				<th>Price</th>
				<th>Description</th>
			</tr>
			 <?php foreach($keySearchXml->categories->category->items->offer as $item_details) {?>
			<tr>
				<td><a href='buy.php?select=<?php print $item_details['id'] ?>'><?php print $item_details->name; ?></a></td>
				<td>$<?php print $item_details->basePrice; ?></td>
				<td><?php print $item_details->description; ?></td>
			</tr>
		<?php } ?>
		</table>
		<?php endif; ?>
	</p>
</body>
</html>