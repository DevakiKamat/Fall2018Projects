
var json;
var title;
var results;
var container;
var myLatLng={lat: 32.75, lng: -97.13};
var map;
var labels = '0123456789';
var labelIndex = 0;
function initialize() {
        myLatLng = {lat: 30.75, lng: -97.13};
        map = new google.maps.Map(document.getElementById('map'), {
        zoom: 16,
        center: myLatLng
  });
  
    }

  function initMap(lat, lng){
  myLatLng = {lat: lat, lng: lng};
  map.setCenter(myLatLng);
  var marker = new google.maps.Marker({
    position: myLatLng,
    map: map,
    label: labels[labelIndex++ % labels.length],
  });
  marker.setMap(map);
  var bounds = new google.maps.LatLngBounds(new google.maps.LatLng(32.91, -101.01), new google.maps.LatLng(32.65, -94.42));
  //var bounds = new google.maps.LatLngBounds(new google.maps.LatLng(27.84, -101.04), new google.maps.LatLng(32.5, -94.45));
  var bounds= map.getBounds();
  var sw = bounds.getNorthEast();
  var ne = bounds.getSouthWest();
  // var strHTML=ne.lat()+","+ne.lng()+"<br>";
  // strHTML+=sw.lat()+","+sw.lng()+"<br>";
  // document.getElementById('container1').innerHTML=strHTML;
  bounds.extend(myLatLng);
  map.fitBounds(bounds);

}

function sendRequest () {
   var width;
   var height; 
   var xhr = new XMLHttpRequest();
   var query = encodeURI(document.getElementById("search").value);
   xhr.open("GET", "proxy.php?term="+query+"+restaurant&location="+query);
   xhr.setRequestHeader("Accept","application/json");
   xhr.onreadystatechange = function () {
       if (this.readyState == 4) {
      json = JSON.parse(this.responseText);
      console.log(json);
      container = document.getElementById("container");
      results=json.businesses.length;
      container.innerHTML="";
      //alert(results);
      for(var i=0;i<10;i++)
      {
      title = document.createElement('a');
      title.setAttribute('href', json.businesses[i].url);
      title.innerHTML = "<li>"+i+"."+"  "+json.businesses[i].name + "<br></li>  ";
      var image = document.createElement('img');
      image.width=100;
      image.height=100;
      image.setAttribute('src', json.businesses[i].image_url);
      var rating=document.createElement('p');
      rating.innerHTML="<b>Rating:</b>"+ "  "+json.businesses[i].rating+ "<br>";
      var lat=json.businesses[i].coordinates.latitude;
      var lng=json.businesses[i].coordinates.longitude;
      initMap(lat,lng);
      container.appendChild(title);
      container.appendChild(rating);
      container.appendChild(image);
     
      }

      }
   };
   xhr.send(null);
}
