package com.company;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import java.io.File;
import java.io.IOException;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;

public class dom {

    public static void main(String[] args) throws ParserConfigurationException, IOException, SAXException {

        //File xmlFile = new File("/reed.xml");

        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder Builder = factory.newDocumentBuilder();
        //System.out.println(new File("reed.xml").getAbsolutePath());
        Document document = Builder.parse(new File("/Users/devaki/IdeaProjects/DOM/reed.xml"));

        document.getDocumentElement().normalize();

//        Element root = document.getDocumentElement();
//        System.out.println(root.getNodeName());


        NodeList nList = document.getElementsByTagName("course");
        System.out.println("\nTitles of all MATH courses that are taught in room LIB 204");
        for (int i = 0; i < nList.getLength(); i++) {
            Node node = nList.item(i);
            //System.out.println("");    //Just a separator
            if (node.getNodeType() == Node.ELEMENT_NODE) {
                //Element eElement = (Element) nList.item(i);
                Element course = (Element) node;
                String subject = course.getElementsByTagName("subj").item(0).getTextContent();
                String building = course.getElementsByTagName("building").item(0).getTextContent();
                String room = course.getElementsByTagName("room").item(0).getTextContent();
                String title = course.getElementsByTagName("title").item(0).getTextContent();
                if (subject.contentEquals("MATH") && building.contentEquals("LIB") && room.contentEquals("204")) {
//                    System.out.println("Building : " + building);
//                    System.out.println("Room : " + room);
                    System.out.println(title);
                }
            }

        }
    }
}