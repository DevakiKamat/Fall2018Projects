package com.company;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.*;
import org.w3c.dom.Element;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import java.io.IOException;

public class xpath {

    public static void main(String[] args) throws IOException, SAXException, ParserConfigurationException, XPathExpressionException {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true); // never forget this!
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document doc = builder.parse("/Users/devaki/IdeaProjects/Xpath/reed.xml");
        XPathFactory xpathfactory = XPathFactory.newInstance();
        XPath xpath = xpathfactory.newXPath();

        XPathExpression expr = xpath.compile("/root/course");
        Object result = expr.evaluate(doc, XPathConstants.NODESET);
        NodeList courses = (NodeList) result;
//        int ns=subject.getLength();
//        System.out.println(ns);


       XPathExpression expr1 = xpath.compile("/root/course/subj/text()");
       Object result1 = expr1.evaluate(doc, XPathConstants.NODESET);
       NodeList subject = (NodeList) result1;

       XPathExpression expr5 = xpath.compile("//course/title/text()");
       Object result5 = expr5.evaluate(doc, XPathConstants.NODESET);
       NodeList title = (NodeList) result5;
////        int nt=title.getLength();
////        System.out.println(nt);
//
       XPathExpression expr2 = xpath.compile("//course/place[building='LIB']");
       Object result2 = expr2.evaluate(doc, XPathConstants.NODESET);
       NodeList building = (NodeList) result2;
////        int nb = building.getLength();
////        System.out.println(nb);


       XPathExpression expr3 = xpath.compile("//course/instructor/text()");
       Object result3 = expr3.evaluate(doc, XPathConstants.NODESET);
       NodeList prof = (NodeList) result3;
//        int np = prof.getLength();
//        System.out.println(np);

       XPathExpression expr4 = xpath.compile("//course/crse/text()");
       Object result4 = expr4.evaluate(doc, XPathConstants.NODESET);
       NodeList code = (NodeList) result4;
//        int nc = code.getLength();
//        System.out.println(nc);


        String sname = " ";
        String stitle = " ";
        String place = " ";
        String cour = " ";
        String instructor = " ";
        String ccode = " ";
        String ititle = " ";
        String instr = " ";
        String room = " ";
        System.out.println("\n1.Print the titles of all MATH courses that are taught in room LIB 204");
        for (int i = 0; i < courses.getLength(); i++) {
            Node node = courses.item(i);
            if (node.getNodeType() == Node.ELEMENT_NODE) {
                Element course = (Element) node;
                sname = course.getElementsByTagName("subj").item(0).getTextContent();
                stitle = course.getElementsByTagName("title").item(0).getTextContent();
                place = course.getElementsByTagName("building").item(0).getTextContent();
                room = course.getElementsByTagName("room").item(0).getTextContent();
                //stitle = title.item(i).getNodeValue();

                //System.out.println(place);
                if (sname.contentEquals("MATH") && place.contentEquals("LIB") && room.contentEquals("204")) {
                    System.out.println(stitle);
                }


            }
        }
        System.out.println("\n2.Print the instructor name who teaches MATH 412");
        for (int j = 0; j < courses.getLength(); j++) {
            Node node1 = courses.item(j);
            if (node1.getNodeType() == Node.ELEMENT_NODE) {
                Element course = (Element) node1;
                cour = course.getElementsByTagName("subj").item(0).getTextContent();
                ccode=course.getElementsByTagName("crse").item(0).getTextContent();
                instructor=course.getElementsByTagName("instructor").item(0).getTextContent();
                if (cour.contentEquals("MATH") && ccode.contentEquals("412")) {
                    System.out.println(instructor);
                }


            }
        }
        System.out.println("\n3.Print the titles of all courses taught by Wieting");
        for (int k = 0; k < courses.getLength(); k++) {
            Node node1 = courses.item(k);
            if (node1.getNodeType() == Node.ELEMENT_NODE) {
                Element course = (Element) node1;
                ititle = course.getElementsByTagName("title").item(0).getTextContent();
                instr=course.getElementsByTagName("instructor").item(0).getTextContent();
                if (instr.contentEquals("Wieting")) {
                    System.out.println(ititle);
                }


            }
        }


    }





}
//}




//




