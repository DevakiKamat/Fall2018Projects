var json;
var str;
var result;
var id;
var disp;
var list;
var genere;
var mid;
var title;
function initialize() {

}

function sendRequest() {
  var xhr = new XMLHttpRequest();
  var query = encodeURI(document.getElementById("form-input").value);
  var container;
  xhr.open("GET", "proxy.php?method=/3/search/movie&query=" + query);
  xhr.setRequestHeader("Accept", "application/json");
  xhr.onreadystatechange = function () {
    if (this.readyState == 4) {
      var json = JSON.parse(this.responseText);
      console.log(json);
      container = document.getElementById("container");
      var releaseDate;
      var image;
      var list;
      var i; 
      var id;
      for (i = 0; i < 20; i++) {
         title = document.createElement('p');
        title.innerHTML = "<a href= '#' onclick='getGenere("+json.results[i].id+");getCast("+json.results[i].id+")'>"+ json.results[i].title  +"</a><br>";

        container.appendChild(title);        

      }
}

    
  };
  xhr.send(null);


}


  function getGenere(title) {
    //alert( title);
  var xhr1 = new XMLHttpRequest();
  xhr1.open("GET", "proxy.php?method=/3/movie/"+title);    //434389");
  xhr1.setRequestHeader("Accept", "application/json");
  var genere = document.createElement('p');
  xhr1.onreadystatechange = function () {
    if (this.readyState == 4) {
      var i;
      var json = JSON.parse(this.responseText);
      var n=json.genres.length;
      genere.innerHTML="<b>Genere: </b>";
      if(n>0)
      {
      for(i=0;i<n;i++)
      {
      genere.innerHTML += json.genres[i].name+",";
      }
      }
      console.log(json);
      var container = document.getElementById("container1");
      container.innerHTML="";
      var title = document.createElement('A');
      title.innerHTML = "<b>Movie Title:</b>" + " " +json.title;
      var releaseDate = document.createElement('p');
      releaseDate.innerHTML = "<b>Release Date:</b>"+json.release_date;
      var ovr=document.createElement('p');
      ovr.innerHTML="<b>Overview:</b>"+ "  "+json.overview;
      var image = document.createElement('img');
        if (json.backdrop_path) {
          image.setAttribute('src', " http://image.tmdb.org/t/p/w185" + json.backdrop_path);
        } else {
          image.setAttribute('src', " http://image.tmdb.org/t/p/w185" + json.poster_path);
        }
        container.appendChild(title);
        container.appendChild(releaseDate);
        container.appendChild(image);
        container.appendChild(genere);
        container.appendChild(ovr);
    }
  };
  xhr1.send(null);

}


function getCast(title) {
    //alert( title);
  var xhr2 = new XMLHttpRequest();
  xhr2.open("GET", "proxy.php?method=/3/movie/"+title+"/credits");
  xhr2.setRequestHeader("Accept", "application/json");
  var cast= document.createElement('p');
  xhr2.onreadystatechange = function () {
    if (this.readyState == 4) {
      var json = JSON.parse(this.responseText);
      var container = document.getElementById("container1");
      ncast=json.cast.length;
      console.log(json);
      //alert(ncast);
      if(ncast>0)
      {
      cast.innerHTML="<b>Cast: </b>";
      for(i=0;i<ncast;i++)
      {
      cast.innerHTML += json.cast[i].character+"<br>" +"&nbsp;"+"&nbsp;"+"&nbsp;"+"&nbsp;"+"&nbsp;"+"&nbsp;"+"&nbsp;"+"&nbsp;"+"&nbsp;"+"&nbsp;";
      }
      container.appendChild(cast);
      }
      
    }
  };
  xhr2.send(null);

}